export class ControlsSkinParams
{
   toStartBtnActive:boolean;
   rwBtnActive:boolean;
   playPauseBtnActive:boolean;
   ffBtnActive:boolean;
   toEndBtnActive:boolean;
   infoBtnActive:boolean;
   soundBtnDisplay:boolean;
   volumeSliderDisplay:boolean;
   showProgressSlider:boolean;
}
