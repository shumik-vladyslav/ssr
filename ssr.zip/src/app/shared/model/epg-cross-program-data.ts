export interface IEpgCrossProgramData
{
  name:string
  startTimeStr:Date;
  endTimeStr:Date;
  startTime:Date
  endTime:Date;
 
  
  

}