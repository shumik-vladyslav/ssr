export enum MenuTypeEnum
{
  Channels = 1,
  Radio = 2,
  Music = 3,
  Options = 4,
  Sharing = 5
}
