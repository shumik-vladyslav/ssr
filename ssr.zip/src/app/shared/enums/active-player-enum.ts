export enum ActivePlayerEnum
{
  main='main',
  adsMain='adsMain',
  AdsSecondary='AdsSecondary'
}
