export enum ControlsSkinTypeEnum
{
   vod = "vod",
   vodSdarot = "vodSdarot",
   live = "live",
   liveRecorded = "liveRecorded",
   pastRecorded = "pastRecorded",
   youtube = "youtube",
   streamFromUrl="streamFromUrl",
   VOD_Folder="VOD_Folder"
}
