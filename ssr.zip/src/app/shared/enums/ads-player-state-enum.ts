export enum AdsPlayerStateEnum
{
  Empty='Empty',
  Waiting='Waiting',
  Playing='Playing',
}
