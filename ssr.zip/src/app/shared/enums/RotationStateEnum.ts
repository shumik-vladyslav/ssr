export enum RotationStateEnum
{
  viewPort="viewPort",
  landScape="landScape",
  portrait="portrait"
}
