export enum BizCallNameEnum
{
  authToken = "authToken",
  generalParams = "generalParams",
  channels = "channels",
  crossEpg = "crossEpg",
  AdvDetails="AdvDetails",
  channelsCMM="channelsCMM"
 
 
}