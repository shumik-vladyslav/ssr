export enum AdsPlayerTypeEnum
{
  cedato="cedato",
  ima="ima"
}
