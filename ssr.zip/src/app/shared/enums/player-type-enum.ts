export enum PlayerTypeEnum {
  youtube="youtube",
  audioTag="audioTag",
  videoGular="videoGular",
  emptyPlayer="emptyPlayer",
  YouTube_Live="YouTube_Live"
}
