import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vod-list',
  templateUrl: './vod-list.component.html',
  styleUrls: ['./vod-list.component.scss']
})
export class VodListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
