import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vod-footer',
  templateUrl: './vod-footer.component.html',
  styleUrls: ['./vod-footer.component.scss']
})
export class VodFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
