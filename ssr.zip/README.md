# StreamTv

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.1.1.

## Prepare

`npm i`

## Development mode

`npm run dev:ssr`

## Production build server and client

`npm run build:ssr`

## Run previous builded

`npm run serve:ssr`